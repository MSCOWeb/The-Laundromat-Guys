<footer></footer>
<script>
function loadCSS(name){
	var fileref=document.createElement("link")
	fileref.setAttribute("rel","stylesheet")
	fileref.setAttribute("type","text/css")
	fileref.setAttribute("href",name)
	document.getElementsByTagName("head")[0].appendChild(fileref)
}
loadCSS('http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800');
loadCSS('//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css');
</script>
<?php wp_footer(); ?>
</html>
</body>